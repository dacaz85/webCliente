// Hook de permisos dinámicos
export const usePermissions = () => { return { permissions: [], hasPermission: () => false }; };