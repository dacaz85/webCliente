// Implementa rutas públicas y privadas conectables al backend
export default function AppRouter() { return null; }