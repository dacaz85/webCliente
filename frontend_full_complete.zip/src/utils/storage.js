// Manejo de cookies para JWT
export const setTokens = () => {};
export const getAccessToken = () => {};
export const getRefreshToken = () => {};
export const removeTokens = () => {};