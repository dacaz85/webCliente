// Funciones de preview y descarga de archivos
export const downloadFile = () => {};
export const previewPDF = () => {};